import Link from 'next/link';
import './globals.css';

export const metadata = {
  title: 'Healthy Kids App',
  description: 'Meal plans, workouts, and trackers for kids',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-gray-50 text-gray-800">
        <header className="bg-blue-600 text-white p-4">
          <nav className="flex space-x-4">
            <Link href="/dashboard" className="hover:underline">Dashboard</Link>
            <Link href="/meal-plans" className="hover:underline">Meal Plans</Link>
            <Link href="/workouts" className="hover:underline">Workouts</Link>
            <Link href="/trackers/water" className="hover:underline">Water</Link>
            <Link href="/trackers/progress" className="hover:underline">Progress</Link>
            <Link href="/reminders" className="hover:underline">Reminders</Link>
          </nav>
        </header>
        <main className="p-4">{children}</main>
      </body>
    </html>
  );
}
