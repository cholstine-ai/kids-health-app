'use client';

export default function Page() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Quick Start Guide</h1>
      <p>This is the Quick Start Guide page of the Healthy Kids App.</p>
    </div>
  );
}
