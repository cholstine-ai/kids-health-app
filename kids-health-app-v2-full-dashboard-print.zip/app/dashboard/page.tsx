'use client';

import { sampleMealPlans } from '@/lib/data/mealPlans';
import { sampleHIIT } from '@/lib/data/hiit';
import { useState, useEffect } from 'react';
import { Line } from 'react-chartjs-2';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

const affirmations = [
  "I am strong and capable.",
  "Every day I get healthier.",
  "I am proud of my progress.",
  "I enjoy moving my body.",
  "I fuel my body with healthy foods.",
  "I am committed to my goals.",
  "I am confident and unstoppable."
];

export default function DashboardPage() {
  const todayMeals = sampleMealPlans.slice(0, 3);
  const todayWorkout = sampleHIIT[0];
  const [waterCups, setWaterCups] = useState(0);
  const [goals, setGoals] = useState({
    meals: false,
    workout: false,
    water: false,
  });

  const [weeklyStats, setWeeklyStats] = useState({
    meals: 5,
    workouts: 4,
    waterDays: 6
  });

  const [dailyAffirmation, setDailyAffirmation] = useState("");

  useEffect(() => {
    const dayIndex = new Date().getDay();
    setDailyAffirmation(affirmations[dayIndex % affirmations.length]);
  }, []);

  const toggleGoal = (goal) => {
    setGoals((prev) => ({ ...prev, [goal]: !prev[goal] }));
  };

  const completedGoals = Object.values(goals).filter(Boolean).length;
  const goalPercentage = (completedGoals / Object.keys(goals).length) * 100;

  const progressLabels = ['Week 1', 'Week 2', 'Week 3', 'Week 4'];
  const weightData = [130, 128, 126, 125]; // Sample weight data

  const data = {
    labels: progressLabels,
    datasets: [
      {
        label: 'Weight (lbs)',
        data: weightData,
        borderColor: 'rgb(37, 99, 235)',
        backgroundColor: 'rgba(37, 99, 235, 0.5)',
        fill: false,
      },
    ],
  };

  const nextWeekMeals = sampleMealPlans.slice(0, 5);
  const nextWeekWorkouts = sampleHIIT.slice(0, 5);

  const generatePlannerPDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text('Weekly Planner - Next Week', 14, 20);
    doc.setFontSize(12);
    doc.text('Meals:', 14, 30);
    nextWeekMeals.forEach((meal, idx) => {
      doc.text(`- ${meal}`, 20, 40 + idx * 8);
    });
    const offset = 40 + nextWeekMeals.length * 8 + 10;
    doc.text('Workouts:', 14, offset);
    nextWeekWorkouts.forEach((workout, idx) => {
      doc.text(`- ${workout}`, 20, offset + 10 + idx * 8);
    });
    doc.save('Weekly_Planner.pdf');
  };

  return (
    <div className="p-4 max-w-4xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold text-blue-700">Home Dashboard</h1>

      <section className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 p-4 rounded">
        <p className="text-lg font-medium">💡 Daily Motivation:</p>
        <p className="mt-2">{dailyAffirmation}</p>
      </section>

      <section className="bg-white shadow-md rounded-lg p-4">
        <h2 className="text-xl font-semibold mb-2 border-b pb-2 flex justify-between items-center">
          Next Week Preview
          <button
            onClick={generatePlannerPDF}
            className="text-sm bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700"
          >
            Print Planner
          </button>
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <h3 className="font-semibold mb-2">Meals</h3>
            <ul className="list-disc pl-6 space-y-1">
              {nextWeekMeals.map((meal, idx) => (
                <li key={idx}>{meal}</li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="font-semibold mb-2">Workouts</h3>
            <ul className="list-disc pl-6 space-y-1">
              {nextWeekWorkouts.map((workout, idx) => (
                <li key={idx}>{workout}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="bg-white shadow-md rounded-lg p-4">
        <h2 className="text-xl font-semibold mb-2 border-b pb-2">Weekly Summary</h2>
        <ul className="list-disc pl-6 space-y-1 text-gray-700">
          <li>Meal Plan Followed: {weeklyStats.meals} days</li>
          <li>Workouts Completed: {weeklyStats.workouts} days</li>
          <li>Water Goal Met: {weeklyStats.waterDays} days</li>
        </ul>
      </section>

      <section className="bg-white shadow-md rounded-lg p-4">
        <h2 className="text-xl font-semibold mb-2 border-b pb-2">Today's Meals</h2>
        <ul className="list-disc pl-6 space-y-1">
          {todayMeals.map((meal, idx) => (
            <li key={idx}>{meal}</li>
          ))}
        </ul>
      </section>

      <section className="bg-white shadow-md rounded-lg p-4">
        <h2 className="text-xl font-semibold mb-2 border-b pb-2">Today's Workout</h2>
        <p className="text-gray-700">{todayWorkout}</p>
      </section>

      <section className="bg-white shadow-md rounded-lg p-4">
        <h2 className="text-xl font-semibold mb-2 border-b pb-2">Water Tracker</h2>
        <p className="mb-2 text-gray-700">Cups: {waterCups}</p>
        <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
          {[...Array(8)].map((_, i) => (
            <button
              key={i}
              onClick={() => setWaterCups(i + 1)}
              className={`px-3 py-2 rounded border text-sm sm:text-base ${
                i < waterCups ? 'bg-blue-500 text-white' : 'bg-gray-100 hover:bg-gray-200'
              }`}
            >
              {i + 1}
            </button>
          ))}
        </div>
      </section>

      <section className="bg-white shadow-md rounded-lg p-4">
        <h2 className="text-xl font-semibold mb-2 border-b pb-2">Progress Overview</h2>
        <div className="h-64">
          <Line data={data} />
        </div>
      </section>

      <section className="bg-white shadow-md rounded-lg p-4">
        <h2 className="text-xl font-semibold mb-2 border-b pb-2">Weekly Goals</h2>
        <ul className="space-y-2 mb-4">
          <li>
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={goals.meals}
                onChange={() => toggleGoal('meals')}
              />
              <span>Followed Meal Plan</span>
            </label>
          </li>
          <li>
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={goals.workout}
                onChange={() => toggleGoal('workout')}
              />
              <span>Completed Workouts</span>
            </label>
          </li>
          <li>
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={goals.water}
                onChange={() => toggleGoal('water')}
              />
              <span>Hit Water Goal</span>
            </label>
          </li>
        </ul>
        <div className="bg-gray-200 rounded h-4 w-full">
          <div
            className="bg-blue-500 h-4 rounded text-right text-xs text-white pr-1"
            style={{ width: `${goalPercentage}%` }}
          >
            {Math.round(goalPercentage)}%
          </div>
        </div>
      </section>
    </div>
  );
}
