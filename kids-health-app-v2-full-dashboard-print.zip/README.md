# Healthy Kids Weight Loss & Fitness App

This Next.js project includes meal plans, grocery lists, workouts, trackers, and more.

## Features
- 4-Week Meal Plans
- Grocery Lists
- HIIT Workouts
- Trackers (Water, Habits, Progress)
- Export to PDF/CSV
- Reminders & Notifications
- PWA Support

## Getting Started
1. Install dependencies: `npm install`
2. Run the development server: `npm run dev`
3. Open [http://localhost:3000](http://localhost:3000)

## Deployment
Click the Deploy with Vercel button in this README.

## Dashboard
A home dashboard page provides a quick view of today's meals, workout, and water intake.
